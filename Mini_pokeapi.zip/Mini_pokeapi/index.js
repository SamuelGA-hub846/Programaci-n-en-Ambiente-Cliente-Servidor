//punto de entrada de la API equivalente al ejecutable 
const App = require('./src/app');
const app = new App();

app.start();