async function getPokemon() {
    const  res = await fetch('https://pokeapi.co/api/v2/pokemon?limit=151')
    const pokemon = await res.json()
    return pokemon.results
}

function shuffle(unshuffled){ //mezcla la lista de pokémons
    const shuffled =unshuffled
    .map((value)=>({
        value, sort: Math.random()
    }))
    .sort((a,b)=> a.sort - b.sort)
    .map(({value})=>value)

    return shuffled
}

function get4Pokemon(randomPokemon){
    return randomPokemon.slice(0,4)
}

function getNumber(url){
    const numberRegex = /(\d+)\/$/
    return (url.match(numberRegex)||[])[1]
}
function getPokemonImage({url}){
    const number = getNumber(url)
    return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${number}.png`
}
window.getPokemonData = async function() {
    const pokemon= await getPokemon()
    const randomPokemon=shuffle(pokemon)
    const pokemonChoices = get4Pokemon(randomPokemon)
    const [firstPokemon] = pokemonChoices
    const image=getPokemonImage(firstPokemon)

    return{
        pokemonChoices: shuffle(pokemonChoices),
        correct: {
            image,
            name: firstPokemon.name
        }
    }
}